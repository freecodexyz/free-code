# Claude Code (CC) 终端网页化设计方案

## 概述

将 Anthropic Claude Code 终端工具改造为现代 Web IDE 界面。视觉语言完全绑定 TRAE Design Library 的 dark-only token 体系和 23 个 `ds-*` 组件。输出为 `.design` 项目，HTML 页面使用 Tailwind CDN + TRAE `colors_and_type.css` + `components.css`。

---

## 当前状态分析

- **TRAE Design Library** 已就绪，路径 `/data/user/design_libraries/TRAE/TRAE(1)/`，提供 dark-only token、23 个组件、2 个 UI Kit（dashboard、dev-explorer）
- **dev-explorer UI Kit** 已有 IDE shell 布局骨架（titlebar + activity-bar + explorer + editor + chat + status bar），与 CC Web UI 目标高度吻合
- 工作区为空，无现有 `.design` 项目

---

## 页面规划

### 页面一：主工作区（核心页面）

CC 的主要交互界面，模拟完整 IDE workbench。

**布局结构**：

```
┌──────────────────────────────────────────────────────────────┐
│  Workbench Titlebar (40px)                                    │
│  [traffic lights] [CC logo] [project selector] [nav actions] │
├────┬──────────┬────────────────────┬─────────────────────────┤
│    │ Sidebar  │  Main Editor Area  │  Chat Panel             │
│ A  │ (可切换)  │                    │                         │
│ c  │ ┌──────┐ │ ┌────────────────┐ │ ┌─────────────────────┐  │
│ t  │ │File  │ │ │ Editor Tabs    │ │ │ Chat Header         │  │
│ i  │ │Tree  │ │ ├────────────────┤ │ ├─────────────────────┤  │
│ v  │ │      │ │ │                │ │ │                     │  │
│ i  │ │      │ │ │  Code Editor   │ │ │  Chat Messages      │  │
│ t  │ │      │ │ │  / Terminal    │ │ │  / Tool Calls       │  │
│ y  │ │      │ │ │  / Diff View   │ │ │                     │  │
│ R  │ │      │ │ │                │ │ ├─────────────────────┤  │
│ a  │ │      │ │ │                │ │ │ Chat Composer       │  │
│ i  │ └──────┘ │ └────────────────┘ │ │ [input + tools]     │  │
│ l  │          │                    │ └─────────────────────┘  │
├────┴──────────┴────────────────────┴─────────────────────────┤
│  Status Bar (24px)                                            │
│  [git branch] [errors] [warnings]      [line:col] [lang]      │
└──────────────────────────────────────────────────────────────┘
```

**区域与 TRAE 组件映射**：

| 区域 | TRAE 组件 | 说明 |
|------|-----------|------|
| Titlebar | `ds-wbtitlebar` | 品牌标识替换为 CC，项目选择器保留 |
| Activity Rail | `ds-activityrail` | 图标替换为 CC 功能入口（文件/搜索/Git/终端/会话/设置） |
| Sidebar 文件树 | `ds-filetree` | 展示项目文件结构，可切换为搜索/Git/会话列表 |
| Editor Tabs | `ds-editortabs` | 已打开文件标签 |
| Chat Composer | `ds-composer` | 模型选择器改为 Claude 模型 |
| Status Bar | `ds-statusbar` | Git 分支、错误计数、光标位置等 |

**CC 特有自定义组件**（使用 TRAE token 构建）：

- **聊天消息气泡**：`--bg-overlay-l1/2` 背景 + `--text-default` 文字 + `--radius-6` 圆角
- **终端输出区**：`--code-terminal-*` 字体 token + `--code-text/doc` 文字色
- **工具调用块**：折叠容器，左侧色条用 `--status-primary/success/error` 标识状态
- **Diff 视图**：新增行 `--status-success-surface-l1`，删除行 `--status-error-surface-l1`
- **Slash 命令面板**：复用 `ds-menu` 样式

### 页面二：会话管理

管理多个并发 CC 会话。

**使用的 TRAE 组件**：`ds-pagehead`、`ds-btn`、`ds-card`、`ds-tag`、`ds-table`、`ds-avatar`、`ds-tabs`（Active/History/Archived 切换）、`ds-dialog`

### 页面三：设置

CC 配置管理（模型选择、权限、外观、快捷键等）。

**使用的 TRAE 组件**：`ds-pagehead`、`ds-navlist`、`ds-settingrow`（三种变体）、`ds-switch`、`ds-btn`、`ds-alert`

---

## 布局架构

### 主工作区 Grid 系统

全屏 IDE workbench，不继承 UI Kit 的 `max-width: 1184px` 约束：

- `grid-template-rows: 40px 1fr 24px`（titlebar | body | statusbar）
- `grid-template-columns: 48px 260px 1fr minmax(0, 480px)`（rail | sidebar | editor | chat）
- 面板可折叠：通过切换 grid-template-columns 实现 sidebar/chat 的显示隐藏

### 面板折叠状态

- 隐藏 sidebar：`48px 0px 1fr minmax(0, 480px)`
- 隐藏 chat：`48px 260px 1fr 0px`
- Zen 模式：`0px 0px 1fr 0px`

---

## 图标资产

从 TRAE 库 `assets/icons/` 复制约 65 个 SVG 到项目 `assets/icons/`，覆盖所有功能区域所需图标（terminal、sparkles、files、search、git、folder、file、chevron、send、plus、x、settings、user、message、copy、refresh、eye、sidebar、layout、code、edit、trash 等）。无需新建任何图标。

---

## 生成顺序

### 阶段 1：项目脚手架

1. 创建项目目录结构
2. 创建 `.design` 项目元数据文件
3. 从 TRAE 库复制所需图标到 `assets/icons/`
4. 创建全局 workbench grid 布局 CSS

### 阶段 2：主工作区页面（核心）

1. HTML 骨架 + CSS 引入（TRAE tokens + components + Tailwind CDN）
2. Workbench Titlebar（`ds-wbtitlebar`）
3. Activity Rail（`ds-activityrail`）
4. Sidebar 文件树（`ds-filetree`）
5. Editor Area（`ds-editortabs` + 自定义编辑器内容）
6. Chat Panel（`ds-composer` + 自定义消息流）
7. Status Bar（`ds-statusbar`）
8. 聊天/编辑器自定义 CSS
9. 面板切换 JS 交互

### 阶段 3 + 4：会话管理 + 设置页面（可与阶段 2 并行）

两个页面互相独立，可并行生成。

### 阶段 5：验证

运行 `scan-design-directory.mjs` 验证 `.design` 文件完整性。

---

## 关键约束

1. **Token 忠诚**：所有颜色/字体/间距必须使用 `var(--token-name)`，禁止硬编码 hex/rem
2. **组件复用**：优先使用 TRAE `ds-*` 组件，CC 特有组件用 TRAE token 构建
3. **Surface 层叠**：`--bg-base-default`（底层）→ `--bg-base-secondary`（常规）→ `--bg-base-tertiary`（凸起）
4. **边框中性**：默认 `--border-neutral-l1`，仅状态特定边框用 status/brand
5. **不复制 UI Kit 容器**：自行写 100vh grid，不从 dev-explorer 复制 `.uikit-shell`
6. **品牌色图标**：`--bg-brand` 表面上的图标使用 `.0c0c0d.svg` 暗色变体

---

## 假设与决策

- **设备类型**：desktop（IDE 工具）
- **操作模式**：library-bound（TRAE Design Library 约束优先）
- **不生成 AI 图片**：所有视觉元素使用 TRAE 组件 + token + SVG 图标实现
- **占位内容**：使用有意义的 CC 相关占位文本（项目名、文件名、代码片段、聊天消息等），不使用 Lorem ipsum
